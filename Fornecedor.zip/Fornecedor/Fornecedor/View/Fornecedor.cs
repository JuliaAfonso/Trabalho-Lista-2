﻿namespace Fornecedor.View
{
    public class Fornecedor
    {
        public string Nome { get; set; }
        public string Email { get; set; }
        public string CodigoId { get; set; }
        public bool Ativo { get; set; }
    }

}
