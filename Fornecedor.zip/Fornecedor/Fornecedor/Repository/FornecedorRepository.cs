﻿using Fornecedor.View;
using MongoDB.Bson.Serialization.Conventions;
using MongoDB.Driver;

namespace Fornecedor.Repository
{
    public class FornecedorRepository
    {
        private readonly IMongoCollection<Fornecedor> _fornecedorCollection;

        public FornecedorRepository(string connectionString, string databaseName)
        {
            var client = new MongoClient(connectionString);
            var database = client.GetDatabase(databaseName);

            // Configurando convenções para mapear propriedades C# para nomes de campos no MongoDB
            var pack = new ConventionPack { new CamelCaseElementNameConvention() };
            ConventionRegistry.Register("camelCase", pack, t => true);

            _fornecedorCollection = database.GetCollection<Fornecedor>("fornecedores");
        }

        public void ReativarFornecedor(string codigoId)
        {
            var filtro = Builders<Fornecedor>.Filter.Eq(f => f.CodigoId, codigoId);
            var update = Builders<Fornecedor>.Update.Set(f => f.Ativo, true);
            _fornecedorCollection.UpdateOne(filtro, update);
        }

        public void DesativarFornecedor(string codigoId)
        {
            var filtro = Builders<Fornecedor>.Filter.Eq(f => f.CodigoId, codigoId);
            var update = Builders<Fornecedor>.Update.Set(f => f.Ativo, false);
            _fornecedorCollection.UpdateOne(filtro, update);
        }

        public Fornecedor ObterPorId(string codigoId)
        {
            return _fornecedorCollection.Find(f => f.CodigoId == codigoId).FirstOrDefault();
        }

        public List<Fornecedor> ObterPorNome(string nome)
        {
            return _fornecedorCollection.Find(f => f.Nome.Contains(nome)).ToList();
        }

        public void AtualizarFornecedor(Fornecedor fornecedor)
        {
            var filtro = Builders<Fornecedor>.Filter.Eq(f => f.CodigoId, fornecedor.CodigoId);
            var update = Builders<Fornecedor>.Update
                .Set(f => f.Nome, fornecedor.Nome)
                .Set(f => f.Email, fornecedor.Email)
                // ... outros campos a serem atualizados
                .Set(f => f.Ativo, fornecedor.Ativo);

            _fornecedorCollection.UpdateOne(filtro, update);
        }

        internal void AtualizarProduto(Produto produto)
        {
            throw new NotImplementedException();
        }
    }

}
