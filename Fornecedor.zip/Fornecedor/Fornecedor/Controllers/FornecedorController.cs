﻿using Fornecedor.Service;
using Microsoft.AspNetCore.Mvc;

namespace Fornecedor.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class FornecedorController : ControllerBase
    {
        private readonly FornecedorService _fornecedorService;

        public FornecedorController(FornecedorService fornecedorService)
        {
            _fornecedorService = fornecedorService;
        }

        // Endpoint para obter todos os fornecedores
        [HttpGet]
        public ActionResult<IEnumerable<Fornecedor>> ObterTodosFornecedores()
        {
            var fornecedores = _fornecedorService.ObterTodosFornecedores();
            return Ok(fornecedores);
        }

        // Endpoint para obter um fornecedor por ID
        [HttpGet("{codigoId}")]
        public ActionResult<Fornecedor> ObterFornecedorPorId(string codigoId)
        {
            var fornecedor = _fornecedorService.ObterFornecedorPorId(codigoId);

            if (fornecedor == null)
            {
                return NotFound();
            }

            return Ok(fornecedor);
        }

        // Endpoint para criar um novo fornecedor
        [HttpPost]
        public ActionResult CriarFornecedor([FromBody] Fornecedor fornecedor)
        {
            _fornecedorService.AdicionarFornecedor(fornecedor);
            return CreatedAtAction(nameof(ObterFornecedorPorId), new { codigoId = fornecedor.CodigoId }, fornecedor);
        }

        // Endpoint para atualizar um fornecedor
        [HttpPut("{codigoId}")]
        public ActionResult AtualizarFornecedor(string codigoId, [FromBody] Fornecedor fornecedor)
        {
            var fornecedorExistente = _fornecedorService.ObterFornecedorPorId(codigoId);

            if (fornecedorExistente == null)
            {
                return NotFound();
            }

            fornecedor.CodigoId = codigoId;
            _fornecedorService.AtualizarFornecedor(fornecedor);

            return NoContent();
        }

        // Endpoint para excluir um fornecedor
        [HttpDelete("{codigoId}")]
        public ActionResult ExcluirFornecedor(string codigoId)
        {
            var fornecedor = _fornecedorService.ObterFornecedorPorId(codigoId);

            if (fornecedor == null)
            {
                return NotFound();
            }

            _fornecedorService.RemoverFornecedor(codigoId);

            return NoContent();
        }
    }

}
