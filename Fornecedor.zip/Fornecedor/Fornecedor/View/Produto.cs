﻿namespace Fornecedor.View
{
    public class Produto
    {
        public string Descricao { get; set; }
        public string? EstoqueMinimo { get; set; }
        public string? EstoqueAtual { get; set; }
    }
}