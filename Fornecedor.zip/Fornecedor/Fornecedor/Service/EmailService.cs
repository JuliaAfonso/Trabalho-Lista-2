﻿
namespace Fornecedor.Service
{
    public class EmailService
    {
        public void EnviarEmail(string v1, string v2, string corpoEmail)
        {
            throw new NotImplementedException();
        }
    }
}