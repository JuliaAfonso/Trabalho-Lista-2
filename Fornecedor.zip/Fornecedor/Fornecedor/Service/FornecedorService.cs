﻿using Fornecedor.Repository;
using Fornecedor.View;

namespace Fornecedor.Service
{
    public class FornecedorService 
    {
        private readonly FornecedorRepository _fornecedorRepository;
        private readonly EmailService _emailService; 

        public FornecedorService(FornecedorRepository fornecedorRepository, EmailService emailService)
        {
            _fornecedorRepository = fornecedorRepository;
            _emailService = emailService;
        }

        public void ReativarFornecedor(string codigoId)
        {
            _fornecedorRepository.ReativarFornecedor(codigoId);
        }

        public void DesativarFornecedor(string codigoId)
        {
            _fornecedorRepository.DesativarFornecedor(codigoId);
        }

        public Fornecedor ObterFornecedorPorId(string codigoId)
        {
            return _fornecedorRepository.ObterPorId(codigoId);
        }

        public List<Fornecedor> ObterFornecedoresPorNome(string nome)
        {
            return _fornecedorRepository.ObterPorNome(nome);
        }

        public void AtualizarFornecedor(Fornecedor fornecedor)
        {
            _fornecedorRepository.AtualizarFornecedor(fornecedor);
        }

        public void AtualizarEstoque(Produto produto, int quantidade)
        {
            // lógica para atualizar estoque

            if (produto.EstoqueAtual.Length < produto.EstoqueMinimo.Length)
            {
                EnviarEmailEstoqueMinimo(produto);
            }
        }

        private void EnviarEmailEstoqueMinimo(Produto produto)
        {
            string corpoEmail = $"Olá Comprador(a), o produto {produto.Descricao} está abaixo do estoque mínimo {produto.EstoqueMinimo} definido no sistema, logo, você precisa avaliar se é necessário realizar um novo pedido de compra.";
            _emailService.EnviarEmail("destinatario@dominio.com", "Assunto: Estoque Mínimo", corpoEmail);
        }

        internal object ObterTodosFornecedores()
        {
            throw new NotImplementedException();
        }

        internal void AdicionarFornecedor(Fornecedor fornecedor)
        {
            throw new NotImplementedException();
        }

        internal void RemoverFornecedor(string codigoId)
        {
            throw new NotImplementedException();
        }
    }
}